package upec.ing1.pds.vsc.models;

public class AdministratorModel {

    private String name;
    private String firstname;
    private String age;

}
