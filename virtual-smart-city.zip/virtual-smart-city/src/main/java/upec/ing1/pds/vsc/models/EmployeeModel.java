package upec.ing1.pds.vsc.models;

public class EmployeeModel {

}
