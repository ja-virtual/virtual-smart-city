package upec.ing1.pds.vsc.views;

public class CompanyView {

}
